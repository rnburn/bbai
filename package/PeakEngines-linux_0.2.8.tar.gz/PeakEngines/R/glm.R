#' Fit a regularized GLM so as to optimize leave-one-out cross-validation
#' 
#' Fit a regularized generalized linear model and select hyperparameters so as to
#' optimize Approximate Leave-one-out Cross-validation (ALO).
#' 
#' @param formula an object of class "formula"
#' @param data a data frame containing the variables to model
#' @param family the class of GLM model (i.e. gaussian or binomial)
#' @param regularizer the class of regularization function to use
#' @param normalize whether to normalize the data before fitting
#'
#' @references Burn, R. (2020)
#' \emph{Optimizing Approximate Leave-one-out Cross-validation to Tune Hyperparameters}\cr
#' \url{https://arxiv.org/abs/2011.10218}\cr
#'
#' @export glmAlo
glmAlo <- function(formula, data, 
                   family = gaussian,
                   regularizer = "ridge",
                   normalize = FALSE, 
                   ...)
{
  cl <- match.call()

  if (is.character(family)) {
    family <- get(family, mode = "function", envir =  parent.frame())
  }
  if(is.function(family))  {
    family <- family()
  }
  if (is.null(family$family)) {
    stop("framily ", family, " not recognized")
  }

  m <- match.call(expand.dots = FALSE)
  num_args <- match(c("formula", "data"), names(m), 0L)
  m <- m[c(1L, num_args)]
  m[[1]] <- quote(stats::model.frame)
  m <- eval.parent(m)

  terms <- attr(m, "terms")
  y <- model.response(m, "any")
  X <- model.matrix(terms, m)

  with_intercept <- attr(terms, "intercept")
  nobs <- length(y)
  num_features <- ncol(X)

  feature_data <- NULL
  if (with_intercept) {
    feature_data <- as.vector(X[, -1])
  } else {
    feature_data <- as.vector(X)
  }
  link <- NULL
  if (family$family == "gaussian")  {
    link <- "l2"
  } else if (family$family == "binomial") {
    link <- "logistic"
  } else {
    stop("invalid family ", family$family)
  }

  linkinv <- family$linkinv
  weights <- rep(1, nobs)
  mustart <- model.extract(m, "mustart")
  etastart <- model.extract(m, "etastart")
  eval(family$initialize)

  fit <- .C("peak_engines_fit_linear_linked_model",
    link = link,
    regularizer = "ridge",
    feature_data = as.double(feature_data),
    target_data = as.double(as.vector(y)),
    num_data = as.integer(nobs),
    num_features = as.integer(num_features - with_intercept),
    normalizer = as.integer(normalize),
    with_intercept = as.integer(with_intercept),
    weight_data = as.double(numeric(ncol(X))),
    lambda = as.double(0),
    rcode = as.integer(0),
    PACKAGE = "PeakEngines"
  )
  if (fit$rcode != 0) {
    stop("fit failed")
  }
  coef <- fit$weight_data
  if (with_intercept) {
    coef <- c(coef[length(coef)], coef[-length(coef)])
  }
  names(coef) <- colnames(X)
  result <- list(
                 call = cl, 
                 family = family,
                 regularizer = regularizer,
                 lambda = fit$lambda,
                 coef = coef, 
                 terms = terms, 
                 x = X, 
                 y = y, 
                 model_frame = m)
  class(result) <- "glmAlo"
  result
}

predict.glmAlo <-
  function(object, newdata = NULL, type = c("link", "response", "terms"),
           ...) {
    type <- match.arg(type)
    terms <- terms(object)
    terms_minus_response <- delete.response(terms)
    m <- model.frame(terms_minus_response, newdata)
    X <- model.matrix(terms_minus_response, m)
    beta <- object$coef
    pred <- X %*% beta
    if (type == "link") {
      return(pred)
    }
    if (type != "response") {
      stop("type ", type, " not supported")
    }
    return(object$family$linkinv(pred))
}
