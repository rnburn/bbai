libname <- "PeakEngines.so"

.onLoad <- function(libpath, pkgname) {
  dyn.load(file.path(libpath, "PeakEngines", "lib", libname), local=FALSE)
}

.onUnloaad <- function (libpath) {
  dyn.unload(file.path(libpath, "PeakEngines", "lib", libname))
}
